<?php return array (
  'beyondcode/laravel-dump-server' => 
  array (
    'providers' => 
    array (
      0 => 'BeyondCode\\DumpServer\\DumpServerServiceProvider',
    ),
  ),
  'codingyu/ueditor' => 
  array (
    'providers' => 
    array (
      0 => 'Codingyu\\Ueditor\\UeditorServiceProvider',
    ),
  ),
  'encore/laravel-admin' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\AdminServiceProvider',
    ),
    'aliases' => 
    array (
      'Admin' => 'Encore\\Admin\\Facades\\Admin',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'jxlwqq/echarts' => 
  array (
    'providers' => 
    array (
      0 => 'Jxlwqq\\Echarts\\EchartsServiceProvider',
    ),
  ),
  'jxlwqq/env-manager' => 
  array (
    'providers' => 
    array (
      0 => 'Jxlwqq\\EnvManager\\EnvManagerServiceProvider',
    ),
  ),
  'jxlwqq/star-rating' => 
  array (
    'providers' => 
    array (
      0 => 'Jxlwqq\\StarRating\\StarRatingServiceProvider',
    ),
  ),
  'laravel-admin-ext/api-tester' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\ApiTester\\ApiTesterServiceProvider',
    ),
  ),
  'laravel-admin-ext/china-distpicker' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\ChinaDistpicker\\ChinaDistpickerServiceProvider',
    ),
  ),
  'laravel-admin-ext/config' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Config\\ConfigServiceProvider',
    ),
  ),
  'laravel-admin-ext/cropper' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Cropper\\CropperServiceProvider',
    ),
  ),
  'laravel-admin-ext/daterangepicker' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\DateRangePicker\\DateRangePickerServiceProvider',
    ),
  ),
  'laravel-admin-ext/helpers' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Helpers\\HelpersServiceProvider',
    ),
  ),
  'laravel-admin-ext/id-validator' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\IdValidator\\IdValidatorServiceProvider',
    ),
  ),
  'laravel-admin-ext/log-viewer' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\LogViewer\\LogViewerServiceProvider',
    ),
  ),
  'laravel-admin-ext/media-player' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\MediaPlayer\\MediaPlayerServiceProvider',
    ),
  ),
  'laravel-admin-ext/phpinfo' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\PHPInfo\\PHPInfoServiceProvider',
    ),
  ),
  'laravel-admin-ext/redis-manager' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\RedisManager\\RedisManagerServiceProvider',
    ),
  ),
  'laravel-admin-extensions/multi-language' => 
  array (
    'providers' => 
    array (
      0 => 'KevinSoft\\MultiLanguage\\MultiLanguageServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'overtrue/laravel-ueditor' => 
  array (
    'providers' => 
    array (
      0 => 'Overtrue\\LaravelUEditor\\UEditorServiceProvider',
    ),
  ),
);