<div class="row">

    <div class="col-md-offset-2 col-md-8">
        <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"><?php echo $name; ?></h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body no-padding">
                    <table class="table table-striped">
                        <tbody>

                        <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(is_a($val, 'Illuminate\Support\Collection')): ?>
                                <tr>
                                    <td><?php echo $key; ?></td>
                                    <td class="phpinfo-v"><?php echo $val[0]; ?></td>
                                    <td><?php echo $val[1]; ?></td>
                                </tr>
                            <?php elseif(is_array($val)): ?>
                                <tr>
                                    <td><?php echo $key; ?></td>
                                    <td class="phpinfo-v"><?php echo $val[0]; ?></td>
                                    <td><?php echo $val[1]; ?></td>
                                </tr>
                            <?php elseif(is_string($key)): ?>
                                <tr>
                                    <td><?php echo $key; ?></td>
                                    <td class="phpinfo-v"><?php echo $val; ?></td>
                                    <td></td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td><?php echo $val; ?></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>

<style>
    .phpinfo-v {
        overflow-x: auto;
        word-wrap: break-word;
        word-break: break-all;
    }
</style>
<?php /**PATH /www/wwwroot/admin.licongying.cn/cmall/vendor/laravel-admin-ext/phpinfo/src/../resources/views/phpinfo.blade.php ENDPATH**/ ?>